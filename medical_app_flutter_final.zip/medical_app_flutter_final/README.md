# تطبيق الرعاية الطبية الذكي

تطبيق Flutter متكامل لمراقبة المؤشرات الحيوية والرعاية الصحية.

## المميزات

- شاشة ترحيب مع أنيميشن جميل
- نظام تسجيل دخول وإنشاء حساب
- التحقق من الهوية برمز OTP
- إعداد الملف الطبي الشامل
- ربط الروبوت الطبي
- لوحة مؤشرات حيوية متقدمة
- تقرير يومي شامل

## المتطلبات

- Flutter 3.0 أو أحدث
- Dart 3.0 أو أحدث
- Android SDK (لبناء APK)

## التثبيت

```bash
flutter pub get
```

## التشغيل

```bash
flutter run
```

## البناء

```bash
flutter build apk --release
```

## الهيكل

```
lib/
├── main.dart
├── constants/
│   └── colors.dart
└── screens/
    ├── splash_screen.dart
    ├── auth_screen.dart
    ├── otp_screen.dart
    ├── medical_profile_screen.dart
    ├── robot_connection_screen.dart
    └── dashboard_screen.dart
```

## الترخيص

MIT License
