import 'package:flutter/material.dart';

class AppColors {
  // الألوان الطبية الأساسية
  static const Color primaryBlue = Color(0xFF0066CC);
  static const Color medicalGreen = Color(0xFF00AA66);
  static const Color lightBlue = Color(0xFFE6F2FF);
  static const Color lightGreen = Color(0xFFE6F9F0);
  
  // ألوان النصوص
  static const Color darkText = Color(0xFF1A1A1A);
  static const Color lightText = Color(0xFF666666);
  static const Color white = Color(0xFFFFFFFF);
  
  // ألوان الحالات
  static const Color success = Color(0xFF00AA66);
  static const Color warning = Color(0xFFFFAA00);
  static const Color error = Color(0xFFCC0000);
  static const Color info = Color(0xFF0066CC);
  
  // ألوان الخلفيات
  static const Color backgroundColor = Color(0xFFF5F5F5);
  static const Color cardBackground = Color(0xFFFFFFFF);
}
