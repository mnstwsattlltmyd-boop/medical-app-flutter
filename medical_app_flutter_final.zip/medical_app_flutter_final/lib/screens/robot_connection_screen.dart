import 'package:flutter/material.dart';
import '../constants/colors.dart';

class RobotConnectionScreen extends StatefulWidget {
  const RobotConnectionScreen({Key? key}) : super(key: key);

  @override
  State<RobotConnectionScreen> createState() => _RobotConnectionScreenState();
}

class _RobotConnectionScreenState extends State<RobotConnectionScreen>
    with SingleTickerProviderStateMixin {
  bool isConnected = false;
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        title: const Text('ربط الروبوت الطبي'),
        backgroundColor: AppColors.primaryBlue,
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (!isConnected)
              ScaleTransition(
                scale: Tween<double>(begin: 1.0, end: 1.3).animate(
                  CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
                ),
                child: Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.lightBlue,
                  ),
                  child: const Icon(
                    Icons.devices,
                    size: 60,
                    color: AppColors.primaryBlue,
                  ),
                ),
              )
            else
              Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.lightGreen,
                ),
                child: const Icon(
                  Icons.check_circle,
                  size: 60,
                  color: AppColors.medicalGreen,
                ),
              ),
            const SizedBox(height: 30),
            Text(
              isConnected ? 'متصل بنجاح' : 'جاري البحث عن الروبوت...',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: isConnected ? AppColors.medicalGreen : AppColors.primaryBlue,
              ),
            ),
            const SizedBox(height: 30),
            if (!isConnected)
              ElevatedButton(
                onPressed: () {
                  setState(() => isConnected = true);
                  Future.delayed(const Duration(seconds: 2), () {
                    if (mounted) {
                      Navigator.pushReplacementNamed(context, '/dashboard');
                    }
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryBlue,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 40,
                    vertical: 15,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Text(
                  'ابحث عن الروبوت',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: AppColors.white,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
