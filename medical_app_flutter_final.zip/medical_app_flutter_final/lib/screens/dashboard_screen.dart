import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';
import '../constants/colors.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int heartRate = 72;
  double temperature = 36.5;
  int oxygenLevel = 98;
  late Timer timer;

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds: 3), (_) {
      setState(() {
        heartRate = 60 + Random().nextInt(40);
        temperature = 36.0 + Random().nextDouble() * 2;
        oxygenLevel = 95 + Random().nextInt(6);
      });
    });
  }

  @override
  void dispose() {
    timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        title: const Text('لوحة المؤشرات'),
        backgroundColor: AppColors.primaryBlue,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Text(
              'المؤشرات الحيوية',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: AppColors.darkText,
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: _buildVitalCard(
                    title: 'نبض القلب',
                    value: '$heartRate',
                    unit: 'نبضة/دقيقة',
                    icon: Icons.favorite,
                    color: AppColors.error,
                  ),
                ),
                const SizedBox(width: 15),
                Expanded(
                  child: _buildVitalCard(
                    title: 'درجة الحرارة',
                    value: temperature.toStringAsFixed(1),
                    unit: '°C',
                    icon: Icons.thermostat,
                    color: AppColors.warning,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 15),
            Row(
              children: [
                Expanded(
                  child: _buildVitalCard(
                    title: 'نسبة الأكسجين',
                    value: '$oxygenLevel',
                    unit: '%',
                    icon: Icons.air,
                    color: AppColors.medicalGreen,
                  ),
                ),
                const SizedBox(width: 15),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.all(15),
                    decoration: BoxDecoration(
                      color: AppColors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 5,
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        const Icon(
                          Icons.check_circle,
                          color: AppColors.medicalGreen,
                          size: 40,
                        ),
                        const SizedBox(height: 10),
                        const Text(
                          'الحالة',
                          style: TextStyle(
                            fontSize: 12,
                            color: AppColors.lightText,
                          ),
                        ),
                        const SizedBox(height: 5),
                        const Text(
                          'طبيعية',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: AppColors.medicalGreen,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 5,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'ملخص التقرير اليومي',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: AppColors.darkText,
                    ),
                  ),
                  const SizedBox(height: 15),
                  _buildReportItem(
                    'متوسط نبض القلب',
                    '${(heartRate - 5 + Random().nextInt(10))} نبضة/دقيقة',
                  ),
                  const SizedBox(height: 10),
                  _buildReportItem(
                    'أعلى درجة حرارة',
                    '${(temperature + 0.5).toStringAsFixed(1)}°C',
                  ),
                  const SizedBox(height: 10),
                  _buildReportItem(
                    'أقل درجة حرارة',
                    '${(temperature - 0.5).toStringAsFixed(1)}°C',
                  ),
                  const SizedBox(height: 10),
                  _buildReportItem(
                    'متوسط نسبة الأكسجين',
                    '${oxygenLevel - 1}%',
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVitalCard({
    required String title,
    required String value,
    required String unit,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 5,
          ),
        ],
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 40),
          const SizedBox(height: 10),
          Text(
            title,
            style: const TextStyle(
              fontSize: 12,
              color: AppColors.lightText,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            value,
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: AppColors.darkText,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            unit,
            style: const TextStyle(
              fontSize: 11,
              color: AppColors.lightText,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReportItem(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 14,
            color: AppColors.lightText,
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: AppColors.darkText,
          ),
        ),
      ],
    );
  }
}
