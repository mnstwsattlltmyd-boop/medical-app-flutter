import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';
import 'screens/auth_screen.dart';
import 'screens/otp_screen.dart';
import 'screens/medical_profile_screen.dart';
import 'screens/robot_connection_screen.dart';
import 'screens/dashboard_screen.dart';

void main() {
  runApp(const MedicalApp());
}

class MedicalApp extends StatelessWidget {
  const MedicalApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'تطبيق الرعاية الطبية',
      theme: ThemeData(
        primaryColor: const Color(0xFF0066CC),
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0066CC),
        ),
      ),
      home: const SplashScreen(),
      routes: {
        '/auth': (context) => const AuthScreen(),
        '/otp': (context) => const OTPScreen(),
        '/medical': (context) => const MedicalProfileScreen(),
        '/robot': (context) => const RobotConnectionScreen(),
        '/dashboard': (context) => const DashboardScreen(),
      },
    );
  }
}
